package com.seleniumspring.epramaan.production;

import java.time.Duration;
import java.util.List;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.demo.seleniumspring.util.AppConstant;

public class LoginUsingMobileNo {
 
	
    @Test
    public void loginWithMobileTest() {
        // Set ChromeDriver system property
        System.setProperty(AppConstant.EPRAMAAN_Driver, AppConstant.EPRAMAAN_DPATH);
        System.out.println("Running Selenium mobile login test...");

        WebDriver driver = new ChromeDriver();
        //WebDriverWait wait = new WebDriverWait(driver, 10); // 10 seconds
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        try {
            driver.manage().window().maximize();
            driver.get(AppConstant.URL);

            // Click on "Mobile" tab
            WebElement mobileTab = wait.until(ExpectedConditions.elementToBeClickable(By.id("mobilebtn")));
            mobileTab.click();

            // Enter Mobile Number
            WebElement mobileField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("user.mobileNumber")));
            mobileField.clear();
            mobileField.sendKeys(AppConstant.MobileNo);
            

            if (driver.findElements(By.id("user.otp")).size() > 0) {
                String captcha = JOptionPane.showInputDialog("Enter OTP");
                driver.findElement(By.id("user.otp")).sendKeys(captcha);
            }

            Thread.sleep(1000);

            // Enter Password
            WebElement passwordField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("user.password")));
            passwordField.clear();
            passwordField.sendKeys(AppConstant.Password);

			/*
			 * // === WAIT UNTIL OTP FIELD IS FILLED === WebElement otpField =
			 * wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("user.otp")));
			 * System.out.println("Waiting for manual OTP input..."); while
			 * (otpField.getAttribute("value").isEmpty()) { Thread.sleep(10000); // check
			 * every 0.5 second } System.out.println("OTP entered manually.");
			 */

           Thread.sleep(1000);


            
            // Wait for the username dropdown to be populated with actual options
            wait.until(driver1 -> {
                List<WebElement> options = driver1.findElements(By.cssSelector("#selectUser option"));
                return options.size() > 1; // Assuming "Select a Username" + actual options
            });

            // Select the first available username (excluding default option)
            Select usernameDropdown = new Select(driver.findElement(By.id("selectUser")));
            List<WebElement> usernames = usernameDropdown.getOptions();

            for (WebElement option : usernames) {
                String val = option.getAttribute("value");
                if (!val.equals("NONE")) {
                    usernameDropdown.selectByVisibleText(option.getText());
                    System.out.println("✅ Username selected: " + option.getText());
                    break;
                }
            }
            
         // Show a dialog popup asking user to enter OTP manually
            String otp = JOptionPane.showInputDialog("Please enter the OTP sent to your mobile");

            // Now send the OTP value into the OTP field on the webpage
            driver.findElement(By.id("user.otp")).sendKeys(otp);

            
            // Click Consent Checkbox
            WebElement consentCheckbox = wait.until(ExpectedConditions.elementToBeClickable(By.id("ssoConsent1")));
            if (!consentCheckbox.isSelected()) {
                consentCheckbox.click();
            }

            // Click Sign In
            WebElement signInButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("submit")));
            signInButton.click();

            System.out.println("Login with mobile and OTP submitted successfully.");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                Thread.sleep(10000); // Optional pause to see result before closing
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            driver.quit();
        }
    }
}
