package com.seleniumspring.epramaan.production;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.demo.seleniumspring.util.AppConstant;

import java.time.Duration;

public class TestLoginUsingAadhar {

    @Test
    public void loginWithAadhaar() {
        // Set Chrome driver path
        System.setProperty(AppConstant.EPRAMAAN_Driver, AppConstant.EPRAMAAN_DPATH);

        System.out.println("Running Selenium Aadhaar/PAN/DL login test...");

        WebDriver driver = new ChromeDriver();
        //WebDriverWait wait = new WebDriverWait(driver, 15);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        driver.manage().deleteAllCookies();

        try {
            driver.manage().window().maximize();
            driver.get(AppConstant.URL);

            // Click on "Aadhaar/PAN/DL" tab
            WebElement othersTab = wait.until(ExpectedConditions.elementToBeClickable(By.id("othersbtn")));
            othersTab.click();

            // Select Aadhaar/PAN/DL from dropdown
            WebElement dropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("selectType")));
            Select select = new Select(dropdown);
            select.selectByValue("aadhaarNumber"); // Change to "panNumber" or "dlNumber" if needed

            // Enter Aadhaar Number
            WebElement idNumberField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("user.otherTypeNumber")));
            idNumberField.clear();
            idNumberField.sendKeys(AppConstant.AadharNo);

            // Enter Password
            WebElement passwordField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("user.password")));
            passwordField.clear();
            passwordField.sendKeys(AppConstant.Password);

            // Check Consent Checkbox
            WebElement consentCheckbox = wait.until(ExpectedConditions.elementToBeClickable(By.id("ssoConsent1")));
            if (!consentCheckbox.isSelected()) {
                consentCheckbox.click();
            }

            // Submit
            WebElement signInButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("submit")));
            js.executeScript("arguments[0].click();", signInButton);
            System.out.println("✅ Login submitted.");

        } catch (Exception e) {
            System.out.println("❌ Exception occurred:");
            e.printStackTrace();
        } finally {
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            driver.quit();
        }
    }
}
