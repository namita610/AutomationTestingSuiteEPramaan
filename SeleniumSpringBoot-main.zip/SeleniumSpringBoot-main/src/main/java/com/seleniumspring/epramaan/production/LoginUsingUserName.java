package com.seleniumspring.epramaan.production;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.demo.seleniumspring.util.AppConstant;

public class LoginUsingUserName {

    // ✅ DataProvider: Supplies multiple sets of credentials
    @DataProvider(name = "userCredentials")
    public Object[][] getUserCredentials() {
        return new Object[][] {
            {AppConstant.Username, AppConstant.Password},
            //{"rohini1974", "Admin@1234"},
            // {"Namita", "Admin@1234"}
        };
    }

    // ✅ Test method: Executes once per credential set
    @Test(dataProvider = "userCredentials")
    public void loginTest(String username, String password) {
        System.setProperty(AppConstant.EPRAMAAN_Driver, AppConstant.EPRAMAAN_DPATH);
        System.out.println("Running Selenium login test for user: " + username);

        WebDriver driver = new ChromeDriver();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        try {
            driver.manage().window().maximize();
            driver.get(AppConstant.URL);

            // ✅ Username input
            WebElement usernameField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("user.username")));
            usernameField.clear();
            usernameField.sendKeys(username);
            Thread.sleep(500);
            Assert.assertEquals(usernameField.getAttribute("value"), username, "Username input mismatch");

            // ✅ Password input
            WebElement passwordField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("user.password")));
            passwordField.clear();
            passwordField.sendKeys(password);
            Thread.sleep(500);
            Assert.assertEquals(passwordField.getAttribute("value"), password, "Password input mismatch");

            // ✅ Consent checkbox
            WebElement consentCheckbox = wait.until(ExpectedConditions.elementToBeClickable(By.id("ssoConsent1")));
            consentCheckbox.click();
            Thread.sleep(300);
            Assert.assertTrue(consentCheckbox.isSelected(), "Consent checkbox was not selected");

            // ✅ Submit login
            WebElement signInButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("submit")));
            signInButton.click();
            System.out.println("Login submitted for user: " + username);

            // ✅ Post-login validation (OPTIONAL: Replace with actual post-login element)
            try {
                WebElement postLoginElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dashboard"))); // Replace 'dashboard' with real ID
                Assert.assertTrue(postLoginElement.isDisplayed(), "Login may have failed — dashboard not visible");
            } catch (TimeoutException e) {
                Assert.fail("Login failed — post-login element not found or timeout.");
            }

            // ✅ Logout menu click
            WebElement userMenuButton = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//*[@id='navbarSupportedContent']/ul[2]/li/button/i")));
            userMenuButton.click();
            Thread.sleep(500);
            Assert.assertTrue(userMenuButton.isDisplayed(), "User menu button is not visible after click");

            // ✅ Logout button click
            WebElement logoutButton = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//button[@type='submit' and @formaction='/logout']")));
            logoutButton.click();
            System.out.println("✅ Logout completed for user: " + username);

        } catch (Exception e) {
            Assert.fail("Test failed for user: " + username + " | Exception: " + e.getMessage(), e);
        } finally {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            driver.quit();
        }
    }
}
